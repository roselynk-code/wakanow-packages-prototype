# Wakanow Packages — Phase 1 prototype

A clickable React prototype of the Packages flow, built from the five Phase 1
mockups and extended into a linked journey.

| Route | Screen | Source |
| --- | --- | --- |
| `/` | Landing — search widget and featured trips | `1-landing-page.html` |
| `/packages` | **Catalogue — every ready-made trip** | new for the prototype |
| `/results` | Search results — three auto-generated tiers | `2-search-results-tiers.html` |
| `/package/:slug` | Package detail with swappable parts | `3-preset-package-detail.html` |
| `/builder` | Five-step custom builder | `4-custom-builder.html` |
| `/checkout` | Checkout and booking summary | `5-checkout-review.html` |

---

## The two ideas that hold it together

### 1. Dates are the spine

`TripContext` holds a real departure and return date. **Trip length is derived
from them, never stored**, and every hotel in the catalogue is held as a
*nightly rate*. So changing the dates anywhere re-prices everything: the tier
cards, the package detail rail, the builder's running total and the checkout
summary all move together.

You can change the dates from the landing search, the catalogue header, the
package detail title bar, or the builder — on any step, including step 5.

The one deliberate asymmetry: **the three tiers keep the length you searched
for**, because they are composed from your search. **A ready-made package
adopts its own duration** when you open it — a 10-night Umrah trip stops
pretending to be a 5-night one — and you can then change it freely.

### 2. Nothing stores a total

`src/data/packages.js` holds only parts: flight options, hotels at a nightly
rate, transfers, bundled tours, optional add-ons. `src/lib/pricing.js` composes
them at the current trip length. That is what makes the dates work, and it means
the "booked separately" figure and the saving can never drift out of step with
the price.

The four packages the mockups authored are decomposed so that at their own
duration they reproduce the published figures **exactly** — ₦1,728,000 for
Dubai, ₦2,448,000 for London, and so on — as do the three tiers
(₦1,486,000 / ₦1,728,000 / ₦3,120,000). Twelve destinations are in the
catalogue; eight are curated for this prototype.

---

## Running it locally

Needs **Node.js 20.19+ or 22.12+** (Node 22 LTS is the safe pick).

```bash
npm install
npm run dev
```

Then open the URL it prints — usually <http://localhost:5173>.

| Command | What it does |
| --- | --- |
| `npm run dev` | Dev server with hot reload |
| `npm run build` | Production build into `dist/` |
| `npm run preview` | Serve the production build locally |
| `npm run lint` | Lint the source |
| `npm run scope-css` | Regenerate the page stylesheets from `mockups/` |
| `npm run harden-css` | Re-raise the shared components' CSS specificity |
| `npm run artifact` | Fold `dist/` into one self-contained HTML file |

Deployment instructions are in **[DEPLOY.md](./DEPLOY.md)**.

---

## How it is put together

```
src/
  main.jsx                entry point
  App.jsx                 routes
  global.css              document background, font default, focus ring
  state/
    TripContext.jsx       provider: dates, party, tier, package being booked
    useTrip.js            the context object and the useTrip() hook
  lib/
    dates.js              date arithmetic and formatting
    pricing.js            pricePackage() — the single source of every total
    format.js             naira() / nairaShort() / delta()
  data/
    packages.js           the catalogue: 12 destinations + 3 tiers
  components/
    DateRangePicker.jsx   two-month range calendar, used on four screens
    BackBar.jsx           back button and breadcrumbs
  pages/
    LandingPage.jsx       + LandingPage.css      (generated)
    PackagesCatalogue.jsx + PackagesCatalogue.css (hand-written)
    SearchResults.jsx     + SearchResults.css    (generated)
    PackageDetail.jsx     + PackageDetail.css    (generated)
    PackageBuilder.jsx    + PackageBuilder.css   (generated)
    Checkout.jsx          + Checkout.css         (generated)
mockups/                  the five original mockups, kept as the source of truth
tools/
  scope-css.mjs           mockup <style> blocks -> scoped page stylesheets
  harden-component-css.mjs raises shared-component specificity (see below)
  make-artifact.mjs       dist/ -> one self-contained HTML file
```

### The page CSS is generated

Each mockup was authored standalone, so they reuse class names (`.opt`, `.tgl`,
`.comp`, `.rail`, `.wrap`) with *different* rules, and several redefine the same
custom properties with different values. `tools/scope-css.mjs` rewrites every
selector to sit under that page's root class — `.pg-landing`, `.pg-results`,
`.pg-detail`, `.pg-builder`, `.pg-checkout` — with `:root`, `html` and `body`
collapsing onto that same wrapper so each page keeps its own token values.

**To change a screen's styling, edit `src/pages/<Page>.css` directly.** Only run
`npm run scope-css` if you changed the original mockup — it overwrites those
five files. `PackagesCatalogue.css` is hand-written and is never regenerated.

### Why the shared components' CSS looks over-qualified

Every generated page stylesheet carries the mockups' `*{margin:0;padding:0}`
reset, scoped to `.pg-x *` — a single class, exactly the same specificity as a
component rule like `.wk-dp-done`. Which one won came down to the order Vite
happened to concatenate the stylesheets, and it differed per page: the date
picker's footer button silently lost its padding on the builder while keeping it
on the landing page.

So the shared components' rules carry an ancestor (`.wk-dp-pop .wk-dp-day`) and
their roots double their own class (`.wk-dp-pop.wk-dp-pop`). That takes them to
two classes, which beats the reset everywhere regardless of bundle order.
`npm run harden-css` reapplies it if you hand-edit those two files.

### Routing

`HashRouter`, so URLs look like `/#/builder` and the prototype works off disk and
on any static host with no rewrite rule. Switch to `BrowserRouter` for clean
URLs, but then the host must serve `index.html` for every path.

---

## Fixed since the first version

- **Checkout described a different trip.** Its sidebar named a hotel, dates and
  airline that appeared nowhere else. It now describes whatever package you
  actually booked, curated destination or tier.
- **Checkout's breakdown did not sum to its own total** — about ₦85,000 out. The
  total is now composed from the booked package plus the switched-on extras, so
  the lines and the total cannot disagree.
- **Only Dubai existed downstream.** Twelve destinations now have full detail
  pages.
- **The builder's running total ignored hotel and flight selection**, because the
  `data-p` price attributes were read by nothing.
- **No way back.** Every screen below the landing page now has a back button and
  breadcrumbs.

---

## Still open

1. **The same hotel is priced differently on two screens.** Rove Downtown is
   ₦99,200 a night on the package detail screen and ₦66,800 in the builder —
   both faithful to their own mockup, which published ₦496,000 and ₦334,000 for
   the same five nights. A pricing-model question, not a code one.
2. **Ineligible options have no separate price.** Bundle-ineligible flights and
   hotels carry `separate === bundled`, so a "booked separately" total including
   one would be understated. It never displays, because that combination shows an
   em dash instead.
3. **Static copy does not follow swaps.** On the detail screen the gallery
   captions and the itinerary text stay fixed after you change flight or hotel.
   The itinerary now stretches and contracts to fit the trip length, but its
   wording is per-package.
4. **The builder's custom combination has no catalogue record.** Proceeding to
   checkout from the builder maps to the closest tier by hotel class, which is an
   approximation.
5. **Checkout is the end.** There is no confirmation screen in the mockups and
   none was invented — "Proceed to Pay" explains the hand-off to the existing
   Wakanow payment flow.
6. **Flight timetables are illustrative.** Only Dubai's Emirates option has a
   real leg-by-leg timetable; other packages show departure and arrival summary
   text only.

---

Prices throughout are illustrative, as the original mockups state.
