# Wakanow Packages — Phase 1 prototype

A clickable React prototype of the Packages flow, built from the five Phase 1
mockups. Five screens, linked into one journey:

| Route | Screen | From mockup |
| --- | --- | --- |
| `/` | Landing — search widget and ready-made trips | `1-landing-page.html` |
| `/results` | Search results — three auto-generated tiers | `2-search-results-tiers.html` |
| `/package/:slug` | Ready-made package detail with swappable parts | `3-preset-package-detail.html` |
| `/builder` | Five-step custom builder | `4-custom-builder.html` |
| `/checkout` | Checkout and booking summary | `5-checkout-review.html` |

**New in the prototype (not in the static mockups):** the screens are wired
together, the search criteria you set on the landing page follow you through
every later screen, and the selected tier carries into checkout.

---

## Running it locally

Needs **Node.js 20.19+ or 22.12+** (Node 22 LTS is the safe pick).

```bash
npm install
npm run dev
```

Then open the URL it prints — usually <http://localhost:5173>.

| Command | What it does |
| --- | --- |
| `npm run dev` | Dev server with hot reload |
| `npm run build` | Production build into `dist/` |
| `npm run preview` | Serve the production build locally |
| `npm run lint` | Lint the source |
| `npm run scope-css` | Regenerate the page stylesheets from `mockups/` |
| `npm run artifact` | Fold `dist/` into one self-contained HTML file |

Deployment instructions are in **[DEPLOY.md](./DEPLOY.md)**.

---

## How it is put together

```
src/
  main.jsx              entry point
  App.jsx               routes
  global.css            document background, font default, focus ring — nothing else
  state/
    TripContext.jsx     provider: search criteria + selected tier
    useTrip.js          the context object and the useTrip() hook
  lib/format.js         naira() / nairaShort() / delta()
  pages/
    LandingPage.jsx     + LandingPage.css
    SearchResults.jsx   + SearchResults.css
    PackageDetail.jsx   + PackageDetail.css
    PackageBuilder.jsx  + PackageBuilder.css
    Checkout.jsx        + Checkout.css
mockups/                the five original HTML mockups, kept as the source of truth
tools/
  scope-css.mjs         mockup <style> blocks -> scoped page stylesheets
  make-artifact.mjs     dist/ -> one self-contained HTML file
```

### The CSS is generated, not hand-written

Each mockup was authored as a standalone page, so they reuse class names
(`.opt`, `.tgl`, `.comp`, `.rail`, `.wrap`) with *different* rules, and several
redefine the same custom properties with different values (`--surface-page`,
`--text-primary`, `--border`). Bundled together they would silently restyle each
other.

`tools/scope-css.mjs` reads each mockup's `<style>` block and rewrites every
selector to sit under that page's root class — `.pg-landing`, `.pg-results`,
`.pg-detail`, `.pg-builder`, `.pg-checkout`. `:root`, `html` and `body`
selectors collapse onto that same wrapper, which is why each page keeps its own
token values.

**So: to change a screen's styling, edit `src/pages/<Page>.css` directly.** Only
re-run `npm run scope-css` if you have changed the original mockup and want to
regenerate from it — it overwrites those five files.

### Routing

`HashRouter`, so URLs look like `/#/builder`. That means the prototype works
when opened straight off disk and on any static host with no rewrite rule
needed. Switch to `BrowserRouter` for clean URLs, but then the host must serve
`index.html` for every path.

### State

`TripContext` deliberately holds only what the mockups show persisting between
screens: the search criteria and the chosen tier. Each screen keeps its own
inventory and pricing local — see the note on price discrepancies below.

---

## Known gaps and things to decide

These are all inherited from the Phase 1 mockups. Nothing was silently
"corrected" — they are product questions, not bugs to patch in a prototype.

1. **Only Dubai is authored end to end.** The landing page shows London,
   Istanbul and Makkah cards, but no downstream screen exists for them. All four
   cards currently open the Dubai package. Either author the other three, or
   have the non-Dubai cards run a search instead.
2. **The same component is priced differently on different screens.** Rove
   Downtown for 5 nights is ₦496,000 on the package detail screen and ₦334,000
   in the builder; the transfer is ₦90,000 in both. Worth settling which is the
   real basis before this informs anything.
3. **Checkout's breakdown does not sum to its own total.** The authored lines
   add up to roughly ₦3,227,731 against a stated total of ₦3,312,834 — about
   ₦85,000 apart. The prototype keeps every authored figure and anchors the
   total to ₦3,312,834, then moves it as you toggle options.
4. **Checkout's summary describes a different trip.** Its sidebar names
   Millennium Plaza Downtown, 26–31 Aug, RwandAir with one stop — the rest of
   the set sells Rove hotels, 12–17 Oct, Emirates or Air Peace direct. It reads
   as a real cart screenshot that was never re-dressed to match.
5. **Ineligible options have no separate price.** On the detail screen the two
   bundle-ineligible options carry `separate === bundled`, so a
   "booked separately" total that included one would be understated. It never
   displays, because that combination shows an em dash instead.
6. **Static copy does not follow swaps.** On the detail screen the title pills,
   gallery captions and day-by-day itinerary stay fixed after you change flight
   or hotel. Fine for Phase 1; a Phase 2 question.
7. **Checkout is the end.** There is no confirmation screen in the mockups and
   none was invented — "Proceed to Pay" explains that this is the hand-off to
   the existing Wakanow payment flow.

### One mockup bug that *was* fixed

In the builder, choosing a different hotel or flight only moved the highlight —
the running total never changed, because the `data-p` price attributes were read
by nothing. Selection now drives the sidebar lines, the grand total and the PSS
figure.

---

Prices throughout are illustrative, as marked in the original mockups.
