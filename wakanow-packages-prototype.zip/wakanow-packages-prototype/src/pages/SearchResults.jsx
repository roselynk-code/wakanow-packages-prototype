import { useNavigate } from 'react-router-dom';

import { naira } from '../lib/format.js';
import { useTrip } from '../state/useTrip.js';
import './SearchResults.css';

/** The WhatsApp glyph, drawn once and shared by all three tier cards. */
const WHATSAPP_PATH =
  'M12 2a10 10 0 00-8.6 15l-1.3 4.7 4.8-1.3A10 10 0 1012 2zm5.8 14.2c-.2.7-1.4 1.3-2 1.4-.5.1-1.1.1-1.8-.1-.4-.1-1-.3-1.7-.6-3-1.3-4.9-4.3-5-4.5-.2-.2-1.2-1.6-1.2-3s.7-2.1 1-2.4c.3-.3.6-.4.8-.4h.6c.2 0 .4 0 .6.5l.9 2.1c.1.2 0 .4-.1.6l-.4.5c-.1.2-.3.3-.1.6.1.3.6 1.1 1.4 1.8 1 .9 1.8 1.1 2 1.3.3.1.4.1.6-.1l.8-.9c.2-.2.4-.2.6-.1l2 1c.2.1.4.2.4.3.1.2.1.7-.1 1.3z';

/** Prices are held as numbers so naira() renders them, but the figures are the
 *  mockup's verbatim: each `save` is exactly `wasPrice - price`. */
const TIERS = [
  {
    key: 'essential',
    name: 'Essential',
    tagline: 'The basics, handled',
    price: 1486000,
    wasPrice: 1571000,
    save: 85000,
    modifier: 't-ess',
    premium: false,
    buttonLabel: 'Select Essential',
    inclusions: [
      { icon: '✈', title: 'Air Peace · Economy', subtitle: 'Direct · LOS → DXB return', off: false },
      { icon: '🏨', title: 'Rove City Centre · 3★', subtitle: '5 nights · room only', off: false },
      { icon: '🚐', title: 'No transfer', subtitle: 'Arrange your own', off: true },
      { icon: '🗺', title: 'No tours', subtitle: 'Explore independently', off: true },
      { icon: '🛂', title: 'Visa · optional add-on', subtitle: '₦96,000 if you need it', off: false },
    ],
  },
  {
    key: 'premium',
    name: 'Premium',
    tagline: 'Key logistics covered',
    price: 1728000,
    wasPrice: 1914000,
    save: 186000,
    modifier: 't-pre',
    premium: true,
    buttonLabel: 'Select Premium',
    inclusions: [
      { icon: '✈', title: 'Emirates · Economy', subtitle: 'Direct · LOS → DXB return · 2×23kg', off: false },
      { icon: '🏨', title: 'Rove Downtown · 4★', subtitle: '5 nights · breakfast included', off: false },
      { icon: '🚐', title: 'Careem shared transfer', subtitle: 'Airport ↔ hotel, both ways', off: false },
      { icon: '🗺', title: '1 featured tour', subtitle: 'Desert safari with BBQ dinner', off: false },
      { icon: '🛂', title: 'Visa · optional add-on', subtitle: '₦96,000 if you need it', off: false },
    ],
  },
  {
    key: 'luxury',
    name: 'Luxury',
    tagline: 'Fully arranged',
    price: 3120000,
    wasPrice: 3478000,
    save: 358000,
    modifier: 't-lux',
    premium: false,
    buttonLabel: 'Select Luxury',
    inclusions: [
      { icon: '✈', title: 'Emirates · Business', subtitle: 'Direct · lounge access · 2×32kg', off: false },
      { icon: '🏨', title: 'Address Downtown · 5★', subtitle: '5 nights · half board · Burj view', off: false },
      { icon: '🚐', title: 'Private chauffeur transfer', subtitle: 'Meet & greet at arrivals', off: false },
      { icon: '🗺', title: '3 curated tours', subtitle: 'Safari, Burj Khalifa, dhow cruise', off: false },
      { icon: '🛂', title: 'Visa · optional add-on', subtitle: '₦96,000 if you need it', off: false },
    ],
  },
];

const NAV_LINKS = ['Flights', 'Hotels', 'Packages', 'Tours', 'Visa'];

export default function SearchResults() {
  const navigate = useNavigate();
  const { search, travellerSummary, setTier } = useTrip();

  const selectTier = (tier) => {
    setTier(tier.name);
    navigate('/checkout');
  };

  const shareOnWhatsApp = (tier) => {
    const text = `${tier.name} package — ${naira(tier.price)} per person — Wakanow`;
    window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank', 'noopener');
  };

  return (
    <div className="pg-results">
      <nav className="nav">
        <div className="wrap">
          <div className="logo">
            waka<i>now</i>
          </div>
          <div className="navlinks">
            {NAV_LINKS.map((link) => (
              <a
                key={link}
                href="#"
                className={link === 'Packages' ? 'on' : undefined}
                onClick={(e) => e.preventDefault()}
              >
                {link}
              </a>
            ))}
          </div>
          <span className="navauth">Log in</span>
        </div>
      </nav>

      <div className="sumbar">
        <div className="wrap">
          <div className="sumchip">
            <span className="l">From</span>
            <span className="v">
              {search.fromCity} ({search.fromCode})
            </span>
          </div>
          <div className="sumchip">
            <span className="l">To</span>
            <span className="v">
              {search.toCity} ({search.toCode})
            </span>
          </div>
          <div className="sumchip">
            <span className="l">Dates</span>
            <span className="v">
              {search.dates} · {search.nights} nights
            </span>
          </div>
          <div className="sumchip">
            <span className="l">Travellers</span>
            <span className="v">{travellerSummary()}</span>
          </div>
          <button className="modify" onClick={() => navigate('/')} aria-label="Modify this search">
            Modify
          </button>
        </div>
      </div>

      <section className="tierzone">
        <div className="wrap">
          <div className="tierhead">
            <h1>Your {search.toCity} trip, three ways</h1>
            <p>Built just now from live prices for your dates. Pick one, or build your own below.</p>
            <div className="visanote">
              ⚠ Visa required for {search.nationality} passports — included as an option in every package
            </div>
          </div>

          <div className="tiers">
            {TIERS.map((tier) => (
              <article
                key={tier.key}
                className={`tier ${tier.modifier}${tier.premium ? ' premium' : ''}`}
              >
                {tier.premium && <div className="ribbon">Recommended</div>}
                <div className="tiertop">
                  <div className="tiername">{tier.name}</div>
                  <div className="tiertag">{tier.tagline}</div>
                  <div className="tierprice">
                    <span className="amt">{naira(tier.price)}</span> <span className="pp">/person</span>
                  </div>
                  <div className="tierwas">{naira(tier.wasPrice)} booked separately</div>
                  <span className="tiersave">Save {naira(tier.save)}</span>
                </div>
                <div className="incl">
                  {tier.inclusions.map((inc) => (
                    <div key={inc.title} className={inc.off ? 'inc off' : 'inc'}>
                      <span className="ic" aria-hidden="true">
                        {inc.icon}
                      </span>
                      <div>
                        <b>{inc.title}</b>
                        <small>{inc.subtitle}</small>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="tierfoot">
                  <button className="selbtn" onClick={() => selectTier(tier)}>
                    {tier.buttonLabel}
                  </button>
                  <div className="selhint">Straight to checkout</div>
                  <div className="tiershare">
                    <button
                      className="washare"
                      onClick={() => shareOnWhatsApp(tier)}
                      aria-label={`Share the ${tier.name} package on WhatsApp`}
                    >
                      <svg viewBox="0 0 24 24" aria-hidden="true">
                        <path d={WHATSAPP_PATH} />
                      </svg>{' '}
                      Share on WhatsApp
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>

          <div className="curated">
            <span className="badge">Curated by Wakanow</span>
            <div>
              <div className="t">Dubai City Break — our Holidays team&apos;s pick for these dates</div>
              <div className="s">
                Emirates direct · Rove Downtown 4★ · Careem transfers · Breakfast · hand-picked tours
              </div>
            </div>
            <div className="price">
              <b>₦1,728,000</b>
              <small>Save ₦186,000</small>
            </div>
            <button
              onClick={() => navigate('/package/dubai-city-break')}
              aria-label="View the Dubai City Break package"
            >
              View package
            </button>
          </div>

          <div className="divider">
            <span>Or build it yourself</span>
          </div>

          <div className="builderentry">
            <div className="be-icon" aria-hidden="true">
              🛠
            </div>
            <div className="be-body">
              <h3>Build your own package</h3>
              <p>
                Choose your exact hotel, flight, transfers and tours step by step. Everything starts
                included — remove what you don&apos;t need. Bundle savings apply to any two or more
                parts.
              </p>
              <div className="be-steps">
                <span className="be-step">1 · Hotel</span>
                <span className="be-step">2 · Flight</span>
                <span className="be-step">3 · Transfer</span>
                <span className="be-step">4 · Tours</span>
                <span className="be-step">5 · Visa</span>
              </div>
            </div>
            <button className="be-cta" onClick={() => navigate('/builder')}>
              Start building
            </button>
          </div>
        </div>
      </section>

      <footer>
        <div className="wrap">
          Wakanow Packages · Phase 1 wireframe · Prices composed from live inventory, illustrative
        </div>
      </footer>
    </div>
  );
}
