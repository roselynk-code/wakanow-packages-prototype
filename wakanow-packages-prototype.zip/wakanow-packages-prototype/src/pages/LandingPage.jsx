import './LandingPage.css';
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { naira, nairaShort } from '../lib/format.js';
import { useTrip } from '../state/useTrip.js';

const COMPONENTS = [
  { key: 'flight', icon: '✈', label: 'Flight' },
  { key: 'hotel', icon: '🏨', label: 'Stay' },
  { key: 'transfer', icon: '🚐', label: 'Transfer' },
  { key: 'tours', icon: '🗺', label: 'Tours' },
];

const CABINS = ['Economy', 'Premium economy', 'Business', 'First'];

const NATIONALITIES = ['Nigeria', 'Ghana', 'United Kingdom', 'United States', 'South Africa'];

const PAX_ROWS = [
  { key: 'adults', title: 'Adults', sub: '12 and over', min: 1 },
  { key: 'children', title: 'Children', sub: '2–11', min: 0 },
  { key: 'infants', title: 'Infants', sub: 'Under 2', min: 0 },
  { key: 'rooms', title: 'Rooms', sub: 'Hotel rooms', min: 1 },
];

const DEST_CHIPS = [
  'All',
  'City Break',
  'Beach & Island',
  'Culture & History',
  'Religious',
  'Family',
  'Romantic',
  'Adventure',
  'Food & Nightlife',
  'Festivals & Events',
  'Safari & Nature',
];

// Every card opens the same builder scenario: Dubai is the only destination the
// Phase 1 mockups author downstream screens for.
const PACKAGE_ROUTE = '/package/dubai-city-break';

const PACKAGES = [
  {
    name: 'Dubai city break',
    duration: '5 nights · Oct 2026 · from Lagos',
    plate: 'p-dxb',
    airline: { name: 'Emirates', note: ' · direct' },
    hotel: { name: 'Rove Downtown', note: ' · 4★' },
    transfer: { icon: '🚐', name: 'Careem', note: ' transfers' },
    vibes: ['City Break', 'Food & Nightlife'],
    tags: ['Visa add-on'],
    was: 1914000,
    now: 1728000,
    save: 186000,
  },
  {
    name: 'London in autumn',
    duration: '6 nights · Nov 2026 · from Lagos',
    plate: 'p-lon',
    airline: { name: 'Air Peace', note: ' · direct' },
    hotel: { name: 'Park Plaza Westminster', note: ' · 4★' },
    transfer: { icon: '🚐', name: 'Blacklane', note: ' transfers' },
    vibes: ['City Break', 'Culture & History'],
    tags: ['Visa required'],
    was: 2689000,
    now: 2448000,
    save: 241000,
  },
  {
    name: 'Istanbul long weekend',
    duration: '4 nights · Sep 2026 · from Lagos',
    plate: 'p-ist',
    airline: { name: 'Turkish Airlines', note: ' · direct' },
    hotel: { name: 'Ramada Old City', note: ' · 4★' },
    transfer: { icon: '🗺', name: 'Istanbul Tour Studio', note: '' },
    vibes: ['Culture & History', 'Food & Nightlife'],
    tags: ['Visa add-on'],
    was: 1436000,
    now: 1302000,
    save: 134000,
  },
  {
    name: 'Makkah & Madinah Umrah',
    duration: '10 nights · Jan 2027 · from Lagos',
    plate: 'p-mak',
    airline: { name: 'Saudia', note: ' · 1 stop' },
    hotel: { name: 'Swissôtel Makkah', note: ' · 5★' },
    transfer: { icon: '🚐', name: 'Al Mashaer', note: ' ground transport' },
    vibes: ['Religious', 'Family'],
    tags: ['Visa incl.'],
    was: 3146000,
    now: 2848000,
    save: 298000,
  },
];

function ShareIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="#004BBE" strokeWidth="2" strokeLinecap="round">
      <circle cx="18" cy="5" r="3" />
      <circle cx="6" cy="12" r="3" />
      <circle cx="18" cy="19" r="3" />
      <path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4" />
    </svg>
  );
}

export default function LandingPage() {
  const navigate = useNavigate();
  const { search, setSearch, travellerLabel } = useTrip();

  const [paxOpen, setPaxOpen] = useState(false);
  const [destChip, setDestChip] = useState('All');

  const paxBtnRef = useRef(null);
  const paxPopRef = useRef(null);

  useEffect(() => {
    if (!paxOpen) return undefined;

    const onPointerDown = (e) => {
      const insideTrigger = paxBtnRef.current?.contains(e.target);
      const insidePopover = paxPopRef.current?.contains(e.target);
      if (!insideTrigger && !insidePopover) setPaxOpen(false);
    };
    const onKeyDown = (e) => {
      if (e.key === 'Escape') setPaxOpen(false);
    };

    document.addEventListener('mousedown', onPointerDown);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('mousedown', onPointerDown);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [paxOpen]);

  const toggleComponent = (key) =>
    setSearch({ components: { [key]: !search.components[key] } });

  const stepPax = (key, delta, min) =>
    setSearch({ [key]: Math.max(min, search[key] + delta) });

  const sharePackage = (e, name) => {
    e.stopPropagation(); // the card itself navigates; sharing should not
    window.open(
      'https://wa.me/?text=' + encodeURIComponent(name + ' — Wakanow Packages'),
      '_blank',
      'noopener',
    );
  };

  const inert = (e) => e.preventDefault();

  return (
    <div className="pg-landing">
      <nav className="nav">
        <div className="wrap">
          <div className="logo">
            waka<i>now</i>
          </div>
          <div className="navlinks">
            <a href="#" onClick={inert}>Flights</a>
            <a href="#" onClick={inert}>Hotels</a>
            <a href="#" className="on" onClick={inert}>Packages</a>
            <a href="#" onClick={inert}>Tours</a>
            <a href="#" onClick={inert}>Visa</a>
            <a href="#" onClick={inert}>Business</a>
          </div>
          <div className="navauth">
            <button className="btn-ghostw">Log in</button>
            <button className="btn-orange">Sign up</button>
          </div>
        </div>
      </nav>

      <header className="hero">
        <div className="wrap">
          <div className="heroline">
            <h1>
              Build your trip. <em>Pay less</em> than booking each part.
            </h1>
            <div className="trustpills">
              <span className="tp">No enquiry forms</span>
              <span className="tp">Named airlines & hotels</span>
              <span className="tp">Pay Small Small</span>
            </div>
          </div>

          <div className="search">
            <div className="comps">
              {COMPONENTS.map(({ key, icon, label }) => {
                const on = search.components[key];
                return (
                  <button
                    key={key}
                    className={on ? 'comp on' : 'comp off'}
                    aria-pressed={on}
                    onClick={() => toggleComponent(key)}
                  >
                    <span className="compcheck" /> {`${icon} ${label}${on ? ' added' : ''}`}
                  </button>
                );
              })}
              <select
                className="cabinsel"
                aria-label="Cabin"
                value={search.cabin}
                onChange={(e) => setSearch({ cabin: e.target.value })}
              >
                {CABINS.map((cabin) => (
                  <option key={cabin}>{cabin}</option>
                ))}
              </select>
            </div>

            <div className="fields">
              <button className="field">
                <span className="lab">From</span>
                <span className="val">{`${search.fromCity} (${search.fromCode})`}</span>
                <span className="hint">{search.fromName}</span>
              </button>
              <button className="field">
                <span className="lab">Going to</span>
                <span className="val">{`${search.toCity} (${search.toCode})`}</span>
                <span className="hint">{search.toName}</span>
              </button>
              <button className="field">
                <span className="lab">Dates</span>
                <span className="val">{search.dates}</span>
                <span className="hint">{`${search.nights} nights`}</span>
              </button>
              <button
                className="field"
                ref={paxBtnRef}
                aria-expanded={paxOpen}
                aria-haspopup="dialog"
                onClick={() => setPaxOpen((open) => !open)}
              >
                <span className="lab">Travellers</span>
                <span className="val">{travellerLabel()}</span>
                <span className="hint">{`${search.nationality} passport`}</span>
              </button>
              <button className="searchgo" onClick={() => navigate('/results')}>
                Search
              </button>
            </div>

            <div className="addDestRow">
              <button className="multidest">+ Add another destination</button>
            </div>

            <div className={paxOpen ? 'pop open' : 'pop'} ref={paxPopRef}>
              {PAX_ROWS.map(({ key, title, sub, min }) => (
                <div className="poprow" key={key}>
                  <div>
                    <div className="t">{title}</div>
                    <div className="s">{sub}</div>
                  </div>
                  <div className="stepper">
                    <button
                      aria-label={`One fewer ${title.toLowerCase()}`}
                      onClick={() => stepPax(key, -1, min)}
                    >
                      −
                    </button>
                    <span>{search[key]}</span>
                    <button
                      aria-label={`One more ${title.toLowerCase()}`}
                      onClick={() => stepPax(key, 1, min)}
                    >
                      +
                    </button>
                  </div>
                </div>
              ))}
              <div className="natfield">
                <label htmlFor="nat">Passport nationality</label>
                <select
                  id="nat"
                  value={search.nationality}
                  onChange={(e) => setSearch({ nationality: e.target.value })}
                >
                  {NATIONALITIES.map((country) => (
                    <option key={country}>{country}</option>
                  ))}
                </select>
              </div>
              <p className="natnote">
                We check visa requirements for this passport when you search.
              </p>
            </div>
          </div>
        </div>
      </header>

      <section className="blk">
        <div className="wrap">
          <div className="secintro">
            <h2>Start from a ready-made trip</h2>
            <button className="seeall" onClick={() => navigate('/results')}>
              See all packages
            </button>
          </div>
          <p className="secnote">
            Curated by our team. Pick one and it opens with the hotel and flight already
            chosen — change anything or go straight to checkout.
          </p>

          <div className="destchips">
            {DEST_CHIPS.map((chip) => (
              <button
                key={chip}
                className={chip === destChip ? 'dc on' : 'dc'}
                aria-pressed={chip === destChip}
                onClick={() => setDestChip(chip)}
              >
                {chip}
              </button>
            ))}
          </div>

          <div className="grid">
            {PACKAGES.map((pkg) => (
              // The whole card is clickable for convenience; the CTA below is the
              // keyboard- and screen-reader-reachable control for the same action.
              <article
                className="card"
                key={pkg.name}
                onClick={() => navigate(PACKAGE_ROUTE)}
              >
                <div className={`plate ${pkg.plate}`}>
                  <button
                    className="sharebtn"
                    aria-label="Share"
                    onClick={(e) => sharePackage(e, pkg.name)}
                  >
                    <ShareIcon />
                  </button>
                  <span className="savebadge">{`Save ${nairaShort(pkg.save)}`}</span>
                </div>
                <div className="cbody">
                  <h3>{pkg.name}</h3>
                  <div className="dur">{pkg.duration}</div>
                  <div className="ops">
                    <div className="op">
                      ✈ <b>{pkg.airline.name}</b>
                      {pkg.airline.note}
                    </div>
                    <div className="op">
                      🏨 <b>{pkg.hotel.name}</b>
                      {pkg.hotel.note}
                    </div>
                    <div className="op">
                      {pkg.transfer.icon} <b>{pkg.transfer.name}</b>
                      {pkg.transfer.note}
                    </div>
                  </div>
                  <div className="incl">
                    {pkg.vibes.map((vibe) => (
                      <span className="vibe" key={vibe}>
                        {vibe}
                      </span>
                    ))}
                    {pkg.tags.map((tag) => (
                      <span className="tag" key={tag}>
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="ledger">
                    <div className="was">{`${naira(pkg.was)} separately`}</div>
                    <div className="nowrow">
                      <span className="now">{naira(pkg.now)}</span>
                      <span className="pp">/person</span>
                    </div>
                    <div className="save">{`You save ${naira(pkg.save)}`}</div>
                  </div>
                  <button className="cta" onClick={() => navigate(PACKAGE_ROUTE)}>
                    Start with this trip
                  </button>
                  <div className="ctahint">Opens builder with parts pre-filled</div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <footer>
        <div className="wrap">
          Wakanow Packages · Phase 1 wireframe · Prices are illustrative
        </div>
      </footer>
    </div>
  );
}
