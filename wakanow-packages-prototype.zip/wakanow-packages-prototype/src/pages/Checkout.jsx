import { Fragment, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { naira } from '../lib/format.js';
import { useTrip } from '../state/useTrip.js';
import './Checkout.css';

const NAV_LINKS = ['Flights', 'Hotels', 'Packages', 'Tours', 'Visa', 'Prime', 'Manage Booking'];

const WHATSAPP_PATH =
  'M12 2a10 10 0 00-8.6 15l-1.3 4.7 4.8-1.3A10 10 0 1012 2zm5.8 14.2c-.2.7-1.4 1.3-2 1.4-.5.1-1.1.1-1.8-.1-.4-.1-1-.3-1.7-.6-3-1.3-4.9-4.3-5-4.5-.2-.2-1.2-1.6-1.2-3s.7-2.1 1-2.4c.3-.3.6-.4.8-.4h.6c.2 0 .4 0 .6.5l.9 2.1c.1.2 0 .4-.1.6l-.4.5c-.1.2-.3.3-.1.6.1.3.6 1.1 1.4 1.8 1 .9 1.8 1.1 2 1.3.3.1.4.1.6-.1l.8-.9c.2-.2.4-.2.6-.1l2 1c.2.1.4.2.4.3.1.2.1.7-.1 1.3z';

/** Tier figures carried over from the search results screen, verbatim. */
const TIERS = [
  { name: 'Essential', modifier: 'ess', price: '₦1,486,000', save: 'Save ₦85K' },
  { name: 'Premium', modifier: 'pre', price: '₦1,728,000', save: 'Save ₦186K' },
  { name: 'Luxury', modifier: 'lux', price: '₦3,120,000', save: 'Save ₦358K' },
];

/** One shared option list per field, so `value` alone decides what is selected —
 *  the mockup faked selection by reordering the options per traveller. */
const TITLES = ['Mrs', 'Mr', 'Ms'];
const GENDERS = ['Female', 'Male'];
const NATIONALITIES = ['Nigeria', 'Ghana', 'UK'];

/** Everything the toggles can add to or remove from the price.
 *  `group` splits the breakdown the way the mockup did: packaging additions
 *  first, then the reminder-style add-ons that already exist on the live cart. */
const OPTIONAL_ITEMS = [
  { key: 'transfer', label: 'Careem airport transfer', price: 90000, isNew: true, group: 'package' },
  { key: 'safari', label: 'Desert safari with dinner', price: 62000, isNew: true, group: 'package' },
  { key: 'visa', label: 'UAE tourist visa', price: 96000, isNew: true, group: 'package' },
  { key: 'callReminder', label: 'Call reminder', price: 2500, isNew: false, group: 'existing' },
  { key: 'smsReminder', label: 'SMS reminder', price: 2000, isNew: false, group: 'existing' },
  { key: 'kalabash', label: 'Kalabash Platinum Travel Card', price: 4500, isNew: false, group: 'existing' },
];

const INITIAL_ADDONS = {
  transfer: true,
  safari: false,
  visa: false,
  callReminder: true,
  smsReminder: true,
  kalabash: false,
};

/** The mockup's authored total, and the package saving it is built from. */
const AUTHORED_TOTAL = 3312834;
const PACKAGE_SAVINGS = 234000;

/** Everything the authored total contains that is *not* switchable. Derived so
 *  the initial render reproduces ₦3,312,834 exactly, then moves with the toggles. */
const FIXED_TOTAL = OPTIONAL_ITEMS.reduce(
  (sum, item) => (INITIAL_ADDONS[item.key] ? sum - item.price : sum),
  AUTHORED_TOTAL,
);

const HOLD_SECONDS = 13 * 60 + 8;

function formatClock(totalSeconds) {
  const mm = Math.floor(totalSeconds / 60);
  const ss = totalSeconds % 60;
  return `${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}`;
}

function WhatsAppGlyph({ size = 18 }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="#fff">
      <path d={WHATSAPP_PATH} />
    </svg>
  );
}

/** A `.tgl` switch — a real switch button wearing the mockup's own classes.
 *  Declared at module scope so toggling does not remount it and drop focus. */
function Toggle({ on, label, onToggle }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      className={on ? 'tgl on' : 'tgl'}
      onClick={onToggle}
    />
  );
}

export default function Checkout() {
  const navigate = useNavigate();
  const { tier, setTier } = useTrip();

  const [email, setEmail] = useState('adaeze.okonkwo@gmail.com');
  const [phone, setPhone] = useState('+234 803 412 6690');
  const [createProfile, setCreateProfile] = useState(false);
  const [travellers, setTravellers] = useState([
    {
      title: 'Mrs',
      firstName: 'Adaeze',
      lastName: 'Okonkwo',
      dob: '15 Mar 1990',
      gender: 'Female',
      nationality: 'Nigeria',
    },
    {
      title: 'Mr',
      firstName: 'Emeka',
      lastName: 'Okonkwo',
      dob: '22 Jul 1988',
      gender: 'Male',
      nationality: 'Nigeria',
    },
  ]);

  const [addons, setAddons] = useState(INITIAL_ADDONS);
  const [channel, setChannel] = useState('whatsapp');
  const [pssSelected, setPssSelected] = useState(false);
  const [handedOff, setHandedOff] = useState(false);
  const [copied, setCopied] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(HOLD_SECONDS);

  useEffect(() => {
    const id = setInterval(() => {
      setSecondsLeft((s) => (s <= 1 ? 0 : s - 1));
    }, 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (!copied) return undefined;
    const id = setTimeout(() => setCopied(false), 2000);
    return () => clearTimeout(id);
  }, [copied]);

  const total = OPTIONAL_ITEMS.reduce(
    (sum, item) => (addons[item.key] ? sum + item.price : sum),
    FIXED_TOTAL,
  );

  const updateTraveller = (index, field, value) =>
    setTravellers((prev) => prev.map((t, i) => (i === index ? { ...t, [field]: value } : t)));

  const toggleAddon = (key) => setAddons((prev) => ({ ...prev, [key]: !prev[key] }));

  const inert = (e) => e.preventDefault();

  const shareOnWhatsApp = () =>
    window.open(
      'https://wa.me/?text=' + encodeURIComponent('My Wakanow booking — ' + naira(total)),
      '_blank',
      'noopener',
    );

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
    } catch {
      // Clipboard is unavailable outside a secure context — leave the label alone.
    }
  };

  const packageLines = OPTIONAL_ITEMS.filter((i) => i.group === 'package' && addons[i.key]);
  const existingLines = OPTIONAL_ITEMS.filter((i) => i.group === 'existing' && addons[i.key]);

  return (
    <div className="pg-checkout">
      <nav className="nav">
        <div className="wrap">
          <div className="logo">
            waka<i>now</i>
          </div>
          <div className="navlinks">
            {NAV_LINKS.map((link) => (
              <a
                key={link}
                href="#"
                className={link === 'Packages' ? 'on' : undefined}
                onClick={inert}
              >
                {link}
              </a>
            ))}
          </div>
          <span className="navauth">Log in / Sign up</span>
        </div>
      </nav>

      <div className="wrap">
        <div className="pagetitle">
          <h1>Your Booking</h1>
        </div>

        <div className="layout">
          <div className="tierside">
            <div className="tierside-head">Your search options</div>
            {TIERS.map((t) => {
              const selected = t.name === tier;
              // `pre` is the mockup's highlight class as well as Premium's own
              // name colour, so it goes on whichever tier is selected — and
              // Premium only carries it when it is the selected one.
              const classes = ['tmini'];
              if (t.modifier !== 'pre') classes.push(t.modifier);
              if (selected) classes.push('pre');
              return (
                <div key={t.name} className={classes.join(' ')}>
                  <div className="tn">{t.name}</div>
                  <div className="tp">
                    <b>{t.price}</b>
                    <small>{t.save}</small>
                  </div>
                  <button type="button" className="go" onClick={() => setTier(t.name)}>
                    {selected ? 'Selected' : 'Switch'}
                  </button>
                </div>
              );
            })}
          </div>

          <main>
            <div className="card">
              <div className="cardhead">
                <h2>
                  <span className="stepnum">1</span>Traveller Details
                </h2>
              </div>

              <div style={{ fontSize: '12px', color: 'var(--text-secondary)', marginBottom: '14px' }}>
                Have an account?{' '}
                <a
                  href="#"
                  style={{ color: 'var(--brand-500)', fontWeight: 600 }}
                  onClick={inert}
                >
                  Log in for faster checkout
                </a>
              </div>

              <div className="frow">
                <div className="f">
                  <label htmlFor="contact-email">Email address</label>
                  <input
                    id="contact-email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="f">
                  <label htmlFor="contact-phone">Phone number</label>
                  <input
                    id="contact-phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </div>
              </div>

              {travellers.map((t, i) => (
                <Fragment key={i}>
                  <div className="travname">
                    {i === 0 ? 'Lead traveller · Adult 1' : `Adult ${i + 1}`}
                  </div>
                  <div className="upload">
                    📄{' '}
                    <div>
                      <b>Upload passport to auto-fill</b>
                      <br />
                      <small>AI will extract name, DOB, nationality & passport details</small>
                    </div>
                    <button type="button" className="addbtn">
                      Upload
                    </button>
                  </div>
                  <div className="frow3">
                    <div className="f">
                      <label htmlFor={`t${i}-title`}>Title</label>
                      <select
                        id={`t${i}-title`}
                        value={t.title}
                        onChange={(e) => updateTraveller(i, 'title', e.target.value)}
                      >
                        {TITLES.map((o) => (
                          <option key={o}>{o}</option>
                        ))}
                      </select>
                    </div>
                    <div className="f">
                      <label htmlFor={`t${i}-first`}>First name</label>
                      <input
                        id={`t${i}-first`}
                        value={t.firstName}
                        onChange={(e) => updateTraveller(i, 'firstName', e.target.value)}
                      />
                    </div>
                    <div className="f">
                      <label htmlFor={`t${i}-last`}>Last name</label>
                      <input
                        id={`t${i}-last`}
                        value={t.lastName}
                        onChange={(e) => updateTraveller(i, 'lastName', e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="frow3">
                    <div className="f">
                      <label htmlFor={`t${i}-dob`}>Date of birth</label>
                      <input
                        id={`t${i}-dob`}
                        value={t.dob}
                        onChange={(e) => updateTraveller(i, 'dob', e.target.value)}
                      />
                    </div>
                    <div className="f">
                      <label htmlFor={`t${i}-gender`}>Gender</label>
                      <select
                        id={`t${i}-gender`}
                        value={t.gender}
                        onChange={(e) => updateTraveller(i, 'gender', e.target.value)}
                      >
                        {GENDERS.map((o) => (
                          <option key={o}>{o}</option>
                        ))}
                      </select>
                    </div>
                    <div className="f">
                      <label htmlFor={`t${i}-nationality`}>Nationality</label>
                      <select
                        id={`t${i}-nationality`}
                        value={t.nationality}
                        onChange={(e) => updateTraveller(i, 'nationality', e.target.value)}
                      >
                        {NATIONALITIES.map((o) => (
                          <option key={o}>{o}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {i === 0 && (
                    <div className="prime">
                      <b>Prime perks:</b> Save your details for faster checkout next time, track
                      bookings from your dashboard, and unlock member-only fares.{' '}
                      <label style={{ marginLeft: '8px' }}>
                        <input
                          type="checkbox"
                          checked={createProfile}
                          onChange={(e) => setCreateProfile(e.target.checked)}
                        />{' '}
                        Create a profile for me
                      </label>
                    </div>
                  )}
                </Fragment>
              ))}

              <div className="terms">
                By proceeding, you agree you have read and accepted our{' '}
                <a href="#" onClick={inert}>
                  Stays
                </a>{' '}
                and our{' '}
                <a href="#" onClick={inert}>
                  Travel Terms & Conditions
                </a>{' '}
                and our{' '}
                <a href="#" onClick={inert}>
                  Privacy Policy
                </a>
                .
              </div>
            </div>

            <div className="card">
              <div className="cardhead">
                <h2>
                  <span className="stepnum">2</span>Enhance Your Trip
                </h2>
                <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                  All add-ons are optional
                </span>
              </div>

              <div className="addon">
                <Toggle
                  on={addons.transfer}
                  label="Careem private airport transfers"
                  onToggle={() => toggleAddon('transfer')}
                />
                <div>
                  <h4>
                    Careem · private airport transfers<span className="new">New</span>
                  </h4>
                  <p>Both ways · meet and greet at DXB arrivals · up to 4 passengers</p>
                </div>
                <div className="price">
                  <b>₦90,000</b>
                  <s>₦94,000 separately</s>
                </div>
              </div>

              <div className="addon">
                <Toggle
                  on={addons.safari}
                  label="Desert safari with dinner"
                  onToggle={() => toggleAddon('safari')}
                />
                <div>
                  <h4>
                    Desert safari with dinner · Arabian Adventures<span className="new">New</span>
                  </h4>
                  <p>Dune drive, camel ride, BBQ dinner · hotel pickup · 6 hours</p>
                </div>
                <div className="price">
                  <b>₦62,000</b>
                  <s>₦74,000 separately</s>
                </div>
              </div>

              <div className="addon">
                <Toggle
                  on={addons.callReminder}
                  label="Call Reminder"
                  onToggle={() => toggleAddon('callReminder')}
                />
                <div>
                  <h4>Call Reminder</h4>
                  <p>Receive call reminders for your flights and stay updated with schedule changes</p>
                </div>
                <div className="price">
                  <b>₦2,500</b>
                </div>
              </div>

              <div className="addon">
                <Toggle
                  on={addons.smsReminder}
                  label="SMS Reminder"
                  onToggle={() => toggleAddon('smsReminder')}
                />
                <div>
                  <h4>SMS Reminder</h4>
                  <p>Get SMS reminders for your flight and stay informed about changes</p>
                </div>
                <div className="price">
                  <b>₦2,000</b>
                </div>
              </div>

              <div className="addon">
                <Toggle
                  on={addons.kalabash}
                  label="Kalabash Platinum Travel Card"
                  onToggle={() => toggleAddon('kalabash')}
                />
                <div>
                  <h4>Kalabash Platinum Travel Card</h4>
                  <p>
                    Purchase the Kalabash USD Platinum card — global payment and cashback. Delivery
                    included.
                  </p>
                </div>
                <div className="price">
                  <b>₦4,500</b>
                </div>
              </div>
            </div>

            <div className="card" style={{ border: '2px solid #C77C00', background: '#FFFCF5' }}>
              <div className="cardhead">
                <h2>
                  <span className="stepnum" style={{ background: '#C77C00' }}>
                    !
                  </span>
                  Visa Requirement<span className="new">New</span>
                </h2>
              </div>
              <div
                style={{
                  background: '#FEF8ED',
                  border: '1px solid rgba(199,124,0,.25)',
                  borderRadius: 'var(--r)',
                  padding: '12px 14px',
                  marginBottom: '14px',
                }}
              >
                <div
                  style={{
                    fontSize: '13px',
                    fontWeight: 700,
                    color: '#C77C00',
                    marginBottom: '4px',
                  }}
                >
                  You need a visa for Dubai on a Nigeria passport
                </div>
                <div style={{ fontSize: '12px', color: '#7A5300', lineHeight: '18px' }}>
                  Wakanow can apply for you. Turn it on below and we'll collect your documents by
                  email after payment. If you already hold a valid UAE visa, leave it off — we will
                  not add it to your price.
                </div>
              </div>
              <div className="addon" style={{ borderBottom: 'none', paddingBottom: 0 }}>
                <Toggle
                  on={addons.visa}
                  label="UAE tourist visa · 30-day single entry"
                  onToggle={() => toggleAddon('visa')}
                />
                <div>
                  <h4>UAE tourist visa · 30-day single entry</h4>
                  <div
                    style={{
                      fontSize: '11px',
                      color: 'var(--text-muted)',
                      marginTop: '2px',
                      lineHeight: '15px',
                    }}
                  >
                    Applied for by Wakanow · 5–7 working days · documents collected after payment
                  </div>
                </div>
                <div className="price">
                  <b>₦96,000</b>
                  <s>₦105,000 separately</s>
                </div>
              </div>
              <div
                style={{
                  fontSize: '10px',
                  color: '#7A5300',
                  marginTop: '10px',
                  paddingTop: '10px',
                  borderTop: '1px solid rgba(199,124,0,.15)',
                  lineHeight: '15px',
                }}
              >
                ⚠ Documents must be submitted within 5 working days of booking. If you do not submit
                in time, Wakanow will contact you before your visa application expires.
              </div>
            </div>

            <div className="card">
              <div className="cardhead">
                <h2>
                  <span className="stepnum" style={{ background: 'var(--brand-500)' }}>
                    ✉
                  </span>
                  How should we reach you?<span className="new">New</span>
                </h2>
              </div>
              <div
                style={{
                  fontSize: '12px',
                  color: 'var(--text-secondary)',
                  marginBottom: '14px',
                  lineHeight: '17px',
                }}
              >
                Choose how you'd like to receive booking confirmations, updates, and visa document
                requests.
              </div>
              <div style={{ display: 'flex', gap: '10px' }}>
                <button
                  type="button"
                  className={channel === 'whatsapp' ? 'commpref sel' : 'commpref'}
                  aria-pressed={channel === 'whatsapp'}
                  onClick={() => setChannel('whatsapp')}
                >
                  <span className="cp-icon" style={{ background: '#25D366' }}>
                    <WhatsAppGlyph />
                  </span>
                  <span className="cp-label">WhatsApp</span>
                  <span className="cp-desc">Get updates on WhatsApp at {phone}</span>
                  <span className="cp-check">✓</span>
                </button>
                <button
                  type="button"
                  className={channel === 'email' ? 'commpref sel' : 'commpref'}
                  aria-pressed={channel === 'email'}
                  onClick={() => setChannel('email')}
                >
                  <span className="cp-icon" style={{ background: 'var(--brand-500)' }}>
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#fff" strokeWidth="2">
                      <rect x="3" y="5" width="18" height="14" rx="2" />
                      <path d="M3 7l9 6 9-6" />
                    </svg>
                  </span>
                  <span className="cp-label">Email</span>
                  <span className="cp-desc">Get updates at {email}</span>
                  <span className="cp-check">✓</span>
                </button>
              </div>
              <div
                style={{
                  fontSize: '10px',
                  color: 'var(--text-muted)',
                  marginTop: '10px',
                  lineHeight: '14px',
                }}
              >
                We'll use this channel for your booking confirmation, itinerary, flight reminders,
                and any visa document requests. You can change this in your account settings after
                booking.
              </div>
            </div>

            <div className="card">
              <div className="cardhead">
                <h2>
                  <span className="stepnum">3</span>Payment
                </h2>
              </div>
              <div className="paylock">
                <svg viewBox="0 0 24 24" fill="none" stroke="#8E8EA9" strokeWidth="2">
                  <rect x="4" y="10" width="16" height="11" rx="2" />
                  <path d="M8 10V7a4 4 0 018 0v3" />
                </svg>
                🔒 Complete the traveller details above to continue to payment.
              </div>
            </div>
          </main>

          <aside className="sidebar">
            <div className="summary">
              <div className="sumhead">
                <h2>Booking Summary</h2>
                <div className="timer">
                  ⏱ Price held for <b>{formatClock(secondsLeft)}</b>
                </div>
              </div>

              <div className="sumbody">
                <div className="sumgroup">
                  <h3>
                    <span className="ic">🏨</span> Hotel
                  </h3>
                  <div className="summeta">Millennium Plaza Downtown Hotel Dubai · 5 nights</div>
                  <div className="summeta">
                    Deluxe Room · Check-in Wed 26 Aug · Check-out Mon 31 Aug
                  </div>
                  <div className="sumprice">₦334,896</div>
                </div>

                <div className="sumgroup">
                  <h3>
                    <span className="ic">✈</span> Flight
                  </h3>
                  <div className="summeta">LOS → DXB · RwandAir · Economy</div>
                  <div className="leg">
                    <div>
                      <span className="time">14:45</span>
                      <br />
                      <span className="code">LOS</span>
                    </div>
                    <div>
                      <span className="dur">14h 45m · 1 stop</span>
                    </div>
                    <div>
                      <span className="time">08:30</span>
                      <br />
                      <span className="code">DXB</span>
                    </div>
                  </div>
                  <div className="summeta" style={{ fontSize: '10px', color: 'var(--text-muted)' }}>
                    1 × 7kg cabin · 2 × 23kg checked
                  </div>
                  <div className="sumprice">₦2,887,938</div>
                </div>

                {addons.transfer && (
                  <div className="sumgroup">
                    <h3>
                      <span className="ic">🚐</span> Airport transfer
                      <span className="new">New</span>
                    </h3>
                    <div className="summeta">Careem · private, both ways</div>
                    <div className="sumprice">₦90,000</div>
                  </div>
                )}

                <div className="savings">
                  <span className="ic">🏷</span>
                  <div>
                    <div className="t">
                      You save {naira(PACKAGE_SAVINGS)} as a package
                      <span className="new" style={{ marginLeft: '4px' }}>
                        New
                      </span>
                    </div>
                    {/* Reads off the live total so the banner cannot contradict it. */}
                    <div className="s">
                      {naira(total + PACKAGE_SAVINGS)} booked separately → {naira(total)} as a
                      package
                    </div>
                  </div>
                </div>

                <div className="sumgroup" style={{ paddingBottom: 0 }}>
                  <div className="bline">
                    <span>RwandAir · LOS → DXB</span>
                  </div>
                  <div className="bline">
                    <span>Flights × 2 travellers</span>
                    <b>₦1,367,718</b>
                  </div>
                  <div className="bline">
                    <span>Taxes</span>
                    <b>₦1,636,476</b>
                  </div>
                  <div className="bline disc">
                    <span>Discount</span>
                    <b>−₦116,256</b>
                  </div>
                  <div className="bline">
                    <span>Service charge</span>
                    <b>₦144,397</b>
                  </div>
                  <div style={{ height: '8px' }} />
                  <div className="bline">
                    <span>Millennium Plaza Downtown Hotel Dubai</span>
                  </div>
                  <div className="bline">
                    <span>1 room × 5 nights × 2 guests</span>
                    <b>₦304,451</b>
                  </div>
                  <div className="bline">
                    <span>Hotel service fee</span>
                    <b>₦30,445</b>
                  </div>
                  <div style={{ height: '8px' }} />

                  {packageLines.map((item) => (
                    <div className="bline" key={item.key}>
                      <span>
                        {item.label}
                        {item.isNew && (
                          <span className="new" style={{ marginLeft: '4px' }}>
                            New
                          </span>
                        )}
                      </span>
                      <b>{naira(item.price)}</b>
                    </div>
                  ))}
                  {packageLines.length > 0 && <div style={{ height: '4px' }} />}

                  {existingLines.map((item) => (
                    <div className="bline" key={item.key}>
                      <span>{item.label}</span>
                      <b>{naira(item.price)}</b>
                    </div>
                  ))}
                  {existingLines.length > 0 && <div style={{ height: '4px' }} />}

                  <div className="bline disc">
                    <span>
                      Package savings
                      <span className="new" style={{ marginLeft: '4px' }}>
                        New
                      </span>
                    </span>
                    <b>−{naira(PACKAGE_SAVINGS)}</b>
                  </div>
                </div>

                <div className="btotal">
                  <span>Total</span>
                  <b>{naira(total)}</b>
                </div>
                <div className="nohidden">No hidden fees — price includes all taxes</div>

                <div
                  className={pssSelected ? 'pssbox sel' : 'pssbox'}
                  role="button"
                  tabIndex={0}
                  aria-pressed={pssSelected}
                  onClick={() => setPssSelected((v) => !v)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setPssSelected((v) => !v);
                    }
                  }}
                >
                  <div className="t">
                    <em>PSS</em> Pay Small Small<span className="new">New</span>
                  </div>
                  <p>
                    Spread this over 6 months from <b>{naira(total / 6)}</b>/month. Nothing extra to
                    pay.
                  </p>
                </div>

                {handedOff ? (
                  <div
                    style={{
                      marginTop: '12px',
                      background: '#F5F7FA',
                      border: '1px solid #D1D1DB',
                      borderRadius: '8px',
                      padding: '14px',
                      fontSize: '12px',
                      color: '#555770',
                      lineHeight: '18px',
                    }}
                  >
                    Phase 1 ends here — this is where Packages hands off to the existing Wakanow
                    payment flow.
                    <button
                      type="button"
                      onClick={() => navigate('/')}
                      style={{
                        display: 'block',
                        marginTop: '10px',
                        background: '#EEF5FF',
                        color: '#004BBE',
                        borderRadius: '8px',
                        padding: '8px 12px',
                        fontSize: '12px',
                        fontWeight: 600,
                      }}
                    >
                      Back to packages
                    </button>
                  </div>
                ) : (
                  <button type="button" className="paybtn" onClick={() => setHandedOff(true)}>
                    Proceed to Pay {naira(total)}
                  </button>
                )}

                <div className="shareacts" style={{ flexDirection: 'column', gap: '8px' }}>
                  <button
                    type="button"
                    onClick={shareOnWhatsApp}
                    style={{
                      flex: 'none',
                      width: '100%',
                      background: '#25D366',
                      color: '#fff',
                      borderRadius: 'var(--r)',
                      padding: '11px',
                      fontSize: '13px',
                      fontWeight: 600,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px',
                    }}
                  >
                    <WhatsAppGlyph />
                    Share itinerary via WhatsApp<span className="new">New</span>
                  </button>
                  <button
                    type="button"
                    onClick={copyLink}
                    style={{
                      flex: 'none',
                      width: '100%',
                      background: '#EEF5FF',
                      color: 'var(--brand-500)',
                      borderRadius: 'var(--r)',
                      padding: '9px',
                      fontSize: '12px',
                      fontWeight: 600,
                    }}
                  >
                    {copied ? 'Link copied' : 'Copy link · Download summary'}
                  </button>
                </div>

                <div className="whats">
                  <div className="wi">
                    <WhatsAppGlyph size={16} />
                  </div>
                  <div>
                    <div className="wt">Something not right?</div>
                    <div className="ws">Message us before you pay</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => window.open('https://wa.me/', '_blank', 'noopener')}
                  >
                    Chat
                  </button>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
