import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { useTrip } from '../state/useTrip.js';
import { naira, delta } from '../lib/format.js';
import './PackageDetail.css';

const FLIGHTS = [
  {
    id: 'em',
    name: 'Emirates · direct both ways',
    desc: 'LOS 22:40 → DXB 07:15 · 7h 35m · 1 bag',
    b: 1142000,
    s: 1268000,
    eligible: true,
    meta: 'Lagos (LOS) → Dubai (DXB) · Economy · 1 checked bag',
  },
  {
    id: 'ap',
    name: 'Air Peace · direct both ways',
    desc: 'LOS 09:20 → DXB 19:05 · 7h 45m · 1 bag',
    b: 1036000,
    s: 1140000,
    eligible: true,
    meta: 'Lagos (LOS) → Dubai (DXB) · Economy · 1 checked bag',
  },
  {
    id: 'qr',
    name: 'Qatar Airways · 1 stop Doha',
    desc: 'LOS 15:10 → DXB 07:40 · 11h 30m · 2 bags',
    b: 1208000,
    s: 1332000,
    eligible: true,
    meta: 'Lagos (LOS) → Doha (DOH) → Dubai (DXB) · Economy · 2 checked bags',
  },
  {
    id: 'tk',
    name: 'Turkish Airlines · 1 stop Istanbul',
    desc: 'LOS 05:45 → DXB 23:10 · 15h 25m · 2 bags',
    b: 1395000,
    s: 1395000,
    eligible: false,
    meta: 'Lagos (LOS) → Istanbul (IST) → Dubai (DXB) · Economy · 2 checked bags',
  },
];

const HOTELS = [
  {
    id: 'rove',
    name: 'Rove Downtown Dubai · 4★',
    desc: 'Deluxe room · breakfast · 900m from Dubai Mall',
    b: 496000,
    s: 552000,
    eligible: true,
    meta: '5 nights · Deluxe room · breakfast included · 900m from Dubai Mall',
  },
  {
    id: 'ibis',
    name: 'Ibis Deira City Centre · 3★',
    desc: 'Standard room · room only · metro at the door',
    b: 352000,
    s: 398000,
    eligible: true,
    meta: '5 nights · Standard room · room only · Deira City Centre metro at the door',
  },
  {
    id: 'addr',
    name: 'Address Beach Resort · 5★',
    desc: 'Sea view room · half board · private beach',
    b: 940000,
    s: 1038000,
    eligible: true,
    meta: '5 nights · Sea view room · half board · private beach at JBR',
  },
  {
    id: 'atl',
    name: 'Atlantis The Palm · 5★',
    desc: 'Ocean deluxe · breakfast · Aquaventure passes',
    b: 1284000,
    s: 1284000,
    eligible: false,
    meta: '5 nights · Ocean deluxe room · breakfast · Aquaventure waterpark passes',
  },
];

// The mockup's `row` field pointed at a DOM node id; the rail line label takes
// its place now that the rows are rendered from state.
const ADDONS = {
  visa: { b: 96000, label: 'UAE tourist visa' },
  safari: { b: 62000, label: 'Desert safari' },
  burj: { b: 48000, label: 'Burj Khalifa entry' },
};
const ADDON_SEP = { visa: 105000, safari: 74000, burj: 56000 };

const TRANSFER_B = 90000;
const TRANSFER_S = 94000;

const EXIT_WARNING =
  'Not part of the bundle. Choosing this drops the package price and you pay each part separately.';

const WHATSAPP_SHARE =
  'https://wa.me/?text=' + encodeURIComponent('Dubai city break — Wakanow Packages');

function find(list, id) {
  return list.filter((x) => x.id === id)[0];
}

export default function PackageDetail() {
  const navigate = useNavigate();
  const { search, payingTravellers } = useTrip();

  const [flightId, setFlightId] = useState('em');
  const [hotelId, setHotelId] = useState('rove');
  const [addons, setAddons] = useState({ visa: false, safari: false, burj: false });
  const [flightDrawerOpen, setFlightDrawerOpen] = useState(false);
  const [hotelDrawerOpen, setHotelDrawerOpen] = useState(false);
  const [saved, setSaved] = useState(false);

  const flight = find(FLIGHTS, flightId);
  const hotel = find(HOTELS, hotelId);
  const bundled = flight.eligible && hotel.eligible;

  const addonKeys = Object.keys(addons);
  const pkg = addonKeys.reduce(
    (sum, k) => (addons[k] ? sum + ADDONS[k].b : sum),
    flight.b + hotel.b + TRANSFER_B,
  );
  const sep = addonKeys.reduce(
    (sum, k) => (addons[k] ? sum + ADDON_SEP[k] : sum),
    flight.s + hotel.s + TRANSFER_S,
  );

  const railNow = pkg;
  const railTotal = pkg * payingTravellers;
  const pssAmount = railTotal / 6;

  const paxLabel = `${payingTravellers} adult${payingTravellers === 1 ? '' : 's'}`;

  const toggleAddon = (key) => setAddons((prev) => ({ ...prev, [key]: !prev[key] }));

  const shareOnWhatsApp = () => window.open(WHATSAPP_SHARE, '_blank', 'noopener');

  const renderOptions = (list, selectedId, select, groupLabel) => (
    <div role="radiogroup" aria-label={groupLabel}>
      {list.map((o) => {
        const current = find(list, selectedId);
        const d = o.b - current.b;
        const selected = o.id === selectedId;
        const choose = () => select(o.id);
        return (
          <div
            key={o.id}
            className={'opt' + (selected ? ' sel' : '') + (o.eligible ? '' : ' exits')}
            role="radio"
            aria-checked={selected}
            tabIndex={0}
            onClick={choose}
            onKeyDown={(e) => {
              if (e.key === ' ' || e.key === 'Enter') {
                e.preventDefault();
                choose();
              }
            }}
          >
            <span className="radio" />
            <div>
              <div className="oname">{o.name}</div>
              <div className="odesc">{o.desc}</div>
              {!o.eligible && <div className="exitwarn">{EXIT_WARNING}</div>}
            </div>
            <div className={'odelta ' + (d < 0 ? 'down' : 'up')}>{delta(d)}</div>
          </div>
        );
      })}
    </div>
  );

  return (
    <div className="pg-detail">
      <nav className="nav">
        <div className="wrap">
          <div className="logo">
            waka<i>now</i>
          </div>
          <div className="navlinks">
            <a href="#" onClick={(e) => e.preventDefault()}>Flights</a>
            <a href="#" onClick={(e) => e.preventDefault()}>Hotels</a>
            <a href="#" className="on" onClick={(e) => e.preventDefault()}>Packages</a>
            <a href="#" onClick={(e) => e.preventDefault()}>Tours</a>
            <a href="#" onClick={(e) => e.preventDefault()}>Visa</a>
            <a href="#" onClick={(e) => e.preventDefault()}>Business</a>
          </div>
          <button type="button" className="btn-ghostw">Log in</button>
        </div>
      </nav>

      <div className="wrap">
        <div className="gallery">
          <div className="shot">
            <span>Downtown Dubai</span>
            <svg viewBox="0 0 400 80" preserveAspectRatio="none" fill="#001845">
              <path d="M0 80V54h22V30h10V14h8v16h12v24h26V40h30v14h18V26h12v28h34V46h24v8h30V22h10v32h28V44h30v10h26V34h14v20h36v26z" />
            </svg>
          </div>
          <div className="shot"><span>Rove Downtown — deluxe room</span></div>
          <div className="shot"><span>Rooftop pool</span></div>
          <div className="shot"><span>Emirates cabin</span></div>
          <div className="shot">
            <span>Desert safari</span>
            <button type="button" className="morephotos">+18 photos</button>
          </div>
        </div>

        <div className="title">
          <div>
            <h1>Dubai city break</h1>
            <div className="sub">
              {search.nights} nights · {search.dates} 2026 · departing {search.fromCity} · {paxLabel}
            </div>
            <div className="pills">
              <span className="pill deal">Save ₦186,000 as a package</span>
              <span className="pill ok">✓ Free cancellation until 26 Sep</span>
              <span className="pill">Emirates · direct both ways</span>
              <span className="pill">4★ hotel with breakfast</span>
              <span className="pill">Private airport transfers</span>
            </div>
          </div>
          <div className="titleacts">
            <button type="button" className="iconbtn" onClick={shareOnWhatsApp}>
              <svg viewBox="0 0 24 24" fill="none" stroke="#4A6078" strokeWidth="2" strokeLinecap="round">
                <circle cx="18" cy="5" r="3" />
                <circle cx="6" cy="12" r="3" />
                <circle cx="18" cy="19" r="3" />
                <path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4" />
              </svg>
              Share
            </button>
            <button type="button" className="iconbtn" onClick={() => setSaved((v) => !v)}>
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="#4A6078"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z" />
              </svg>
              {saved ? 'Saved' : 'Save'}
            </button>
          </div>
        </div>

        <div className="layout">
          <main>
            <section className="sec">
              <div className="sechead">
                <h2>What's in this package</h2>
                <span className="note">Change the flight or hotel and keep the bundle price</span>
              </div>

              <div className="comp">
                <div className="comphead">
                  <div className="cicon">✈</div>
                  <div>
                    <h3>{flight.name}</h3>
                    <div className="meta">{flight.meta}</div>
                  </div>
                  <div className="price">
                    <b>{naira(flight.b)}</b>
                    <s>{flight.eligible ? naira(flight.s) + ' separately' : 'not in the bundle'}</s>
                  </div>
                </div>
                {/* The timetable below is Emirates-specific, so it only stands for that flight. */}
                {flight.id === 'em' && (
                  <div className="legdetail">
                    <div className="leg"><b>22:40</b>LOS · Mon 12 Oct</div>
                    <div className="leg"><b>07:15</b>DXB · Tue 13 Oct</div>
                    <div className="leg"><b>7h 35m</b>Direct outbound</div>
                    <div className="leg"><b>03:20</b>DXB · Sat 17 Oct</div>
                    <div className="leg"><b>08:55</b>LOS · Sat 17 Oct</div>
                  </div>
                )}
                <button
                  type="button"
                  className="swapbtn"
                  onClick={() => setFlightDrawerOpen((v) => !v)}
                >
                  {flightDrawerOpen ? 'Close flight' : 'Change flight'}
                </button>
                <div className={'swapbox' + (flightDrawerOpen ? ' open' : '')}>
                  {renderOptions(FLIGHTS, flightId, setFlightId, 'Choose a flight')}
                </div>
              </div>

              <div className="comp">
                <div className="comphead">
                  <div className="cicon">🏨</div>
                  <div>
                    <h3>{hotel.name}</h3>
                    <div className="meta">{hotel.meta}</div>
                  </div>
                  <div className="price">
                    <b>{naira(hotel.b)}</b>
                    <s>{hotel.eligible ? naira(hotel.s) + ' separately' : 'not in the bundle'}</s>
                  </div>
                </div>
                <button
                  type="button"
                  className="swapbtn"
                  onClick={() => setHotelDrawerOpen((v) => !v)}
                >
                  {hotelDrawerOpen ? 'Close hotel' : 'Change hotel'}
                </button>
                <div className={'swapbox' + (hotelDrawerOpen ? ' open' : '')}>
                  {renderOptions(HOTELS, hotelId, setHotelId, 'Choose a hotel')}
                </div>
              </div>

              <div className="comp">
                <div className="comphead">
                  <div className="cicon">🚐</div>
                  <div>
                    <h3>Careem · private airport transfers</h3>
                    <div className="meta">Both ways · meet and greet at arrivals · up to 4 passengers</div>
                  </div>
                  <div className="price">
                    <b>{naira(TRANSFER_B)}</b>
                    <s>{naira(TRANSFER_S)} separately</s>
                  </div>
                </div>
              </div>
            </section>

            <section className="sec">
              <div className="sechead">
                <h2>Add anything else you need</h2>
                <span className="note">Price updates as you go</span>
              </div>

              <div className="visabar">
                <b>You need a visa for Dubai on a Nigeria passport.</b> Wakanow can apply on your
                behalf — turn it on below and we'll collect your documents after payment. If you
                already hold a valid UAE visa, leave it off.
              </div>

              <div className="addon">
                {/* A real button handles Space and Enter natively, which is what the
                    mockup's keydown handler was reproducing by hand. */}
                <button
                  type="button"
                  className={'tgl' + (addons.visa ? ' on' : '')}
                  role="switch"
                  aria-checked={addons.visa}
                  aria-label="UAE tourist visa"
                  onClick={() => toggleAddon('visa')}
                />
                <div>
                  <h3>UAE tourist visa</h3>
                  <div className="meta">
                    30-day single entry · Wakanow handles the application · 5–7 working days
                  </div>
                </div>
                <div className="ap">
                  <b>+₦96,000</b>
                  <s>₦105,000 separately</s>
                </div>
              </div>

              <div className="addon">
                <button
                  type="button"
                  className={'tgl' + (addons.safari ? ' on' : '')}
                  role="switch"
                  aria-checked={addons.safari}
                  aria-label="Desert safari with dinner"
                  onClick={() => toggleAddon('safari')}
                />
                <div>
                  <h3>Desert safari with dinner — Arabian Adventures</h3>
                  <div className="meta">Dune drive, camel ride, BBQ dinner · hotel pickup · 6 hours</div>
                </div>
                <div className="ap">
                  <b>+₦62,000</b>
                  <s>₦74,000 separately</s>
                </div>
              </div>

              <div className="addon">
                <button
                  type="button"
                  className={'tgl' + (addons.burj ? ' on' : '')}
                  role="switch"
                  aria-checked={addons.burj}
                  aria-label="Burj Khalifa: At the Top"
                  onClick={() => toggleAddon('burj')}
                />
                <div>
                  <h3>Burj Khalifa: At the Top, levels 124 & 125</h3>
                  <div className="meta">Timed entry · sunset slot held for package guests</div>
                </div>
                <div className="ap">
                  <b>+₦48,000</b>
                  <s>₦56,000 separately</s>
                </div>
              </div>
            </section>

            <section className="sec">
              <div className="sechead"><h2>Your five days</h2></div>
              <div className="itin">
                <div className="day">Day 1</div>
                <p>
                  <b>Overnight flight and check-in.</b> Land at DXB 07:15, Careem driver meets you at
                  arrivals, early check-in held at Rove Downtown.
                </p>
              </div>
              <div className="itin">
                <div className="day">Day 2</div>
                <p>
                  <b>Downtown at your own pace.</b> Dubai Mall and the fountain show are a ten-minute
                  walk from the hotel.
                </p>
              </div>
              <div className="itin">
                <div className="day">Day 3</div>
                <p>
                  <b>Free day.</b> Add the desert safari above if you want it filled — it runs from
                  15:00 with hotel pickup.
                </p>
              </div>
              <div className="itin">
                <div className="day">Day 4</div>
                <p>
                  <b>Old Dubai.</b> Abra crossing to the gold and spice souks in Deira, then back for
                  the evening.
                </p>
              </div>
              <div className="itin">
                <div className="day">Day 5</div>
                <p>
                  <b>Late checkout and departure.</b> Room held until 18:00, transfer to DXB for the
                  03:20 flight home.
                </p>
              </div>
            </section>
          </main>

          <aside className="rail">
            <div className="pricecard">
              <div className="priceledger">
                <div className="lbl">Booked separately</div>
                <div className="was">{bundled ? naira(sep) : '—'}</div>
                <div className="lbl" style={{ marginTop: '12px' }}>As a package</div>
                <div className="now">{naira(railNow)}</div>
                <div className="pp">per person · {paxLabel}</div>
                <div
                  className="savechip"
                  style={{ background: bundled ? 'var(--accent-400)' : 'rgba(255,255,255,.18)' }}
                >
                  {bundled
                    ? 'You save ' + naira(sep - pkg) + ' per person'
                    : 'No bundle price on this combination'}
                </div>
              </div>
              <div className="pcbody">
                <div className="line"><span>Flights</span><b>{naira(flight.b)}</b></div>
                <div className="line"><span>Hotel · 5 nights</span><b>{naira(hotel.b)}</b></div>
                <div className="line"><span>Airport transfers</span><b>{naira(TRANSFER_B)}</b></div>
                {addons.visa && (
                  <div className="line">
                    <span>{ADDONS.visa.label}</span><b>{naira(ADDONS.visa.b)}</b>
                  </div>
                )}
                {addons.safari && (
                  <div className="line">
                    <span>{ADDONS.safari.label}</span><b>{naira(ADDONS.safari.b)}</b>
                  </div>
                )}
                {addons.burj && (
                  <div className="line">
                    <span>{ADDONS.burj.label}</span><b>{naira(ADDONS.burj.b)}</b>
                  </div>
                )}
                <div className="line total">
                  <span>Total for {paxLabel}</span><b>{naira(railTotal)}</b>
                </div>

                <div className="pssbox">
                  <div className="t"><em>PSS</em> Pay Small Small</div>
                  <p>
                    Spread this booking over 6 months from <b>{naira(pssAmount)}</b> a month. Nothing
                    extra to pay — your travel documents are issued on the final instalment.
                  </p>
                </div>

                <button type="button" className="booknow" onClick={() => navigate('/checkout')}>
                  Book this package
                </button>
                <div className="railacts">
                  <button type="button" onClick={shareOnWhatsApp}>Share</button>
                  <button type="button" onClick={() => setSaved((v) => !v)}>
                    {saved ? 'Saved' : 'Save for later'}
                  </button>
                </div>

                <div className="whats">
                  <div className="wi">
                    <svg viewBox="0 0 24 24">
                      <path d="M12 2a10 10 0 00-8.6 15l-1.3 4.7 4.8-1.3A10 10 0 1012 2zm5.8 14.2c-.2.7-1.4 1.3-2 1.4-.5.1-1.1.1-1.8-.1-.4-.1-1-.3-1.7-.6-3-1.3-4.9-4.3-5-4.5-.2-.2-1.2-1.6-1.2-3s.7-2.1 1-2.4c.3-.3.6-.4.8-.4h.6c.2 0 .4 0 .6.5l.9 2.1c.1.2 0 .4-.1.6l-.4.5c-.1.2-.3.3-.1.6.1.3.6 1.1 1.4 1.8 1 .9 1.8 1.1 2 1.3.3.1.4.1.6-.1l.8-.9c.2-.2.4-.2.6-.1l2 1c.2.1.4.2.4.3.1.2.1.7-.1 1.3z" />
                    </svg>
                  </div>
                  <div>
                    <div className="wt">Talk to a person on WhatsApp</div>
                    <div className="ws">Usually replies in a few minutes</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => window.open('https://wa.me/', '_blank', 'noopener')}
                  >
                    Chat
                  </button>
                </div>

                <p className="railfoot">
                  Price shown is the price charged. Naira only — no exchange rate adjustment between
                  now and payment.
                </p>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
