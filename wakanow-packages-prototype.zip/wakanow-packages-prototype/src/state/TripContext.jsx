import { useMemo, useState } from 'react';

import { TripContext } from './useTrip.js';

/**
 * Carries the search criteria and the chosen tier across screens.
 *
 * Deliberately narrow: it holds what the mockups show persisting between
 * screens (the summary bar's search terms, and which tier the traveller
 * picked). Each screen keeps its own inventory and pricing local, because
 * the Phase 1 mockups price the same components differently depending on
 * the path — that is a question for the pricing model, not something this
 * prototype should quietly average away.
 */

const DEFAULT_SEARCH = {
  fromCity: 'Lagos',
  fromCode: 'LOS',
  fromName: 'Murtala Muhammed',
  toCity: 'Dubai',
  toCode: 'DXB',
  toName: 'United Arab Emirates',
  dates: '12 – 17 Oct',
  nights: 5,
  cabin: 'Economy',
  adults: 2,
  children: 0,
  infants: 0,
  rooms: 1,
  nationality: 'Nigeria',
  components: { flight: true, hotel: true, transfer: false, tours: false },
};

export function TripProvider({ children }) {
  const [search, setSearchState] = useState(DEFAULT_SEARCH);
  const [tier, setTier] = useState('Premium');

  const value = useMemo(() => {
    /** Merge a partial update into the search criteria. */
    const setSearch = (patch) =>
      setSearchState((prev) => ({
        ...prev,
        ...patch,
        components: { ...prev.components, ...(patch.components ?? {}) },
      }));

    /** "2 adults, 1 room" — the traveller field label on the landing page. */
    const travellerLabel = () => {
      const parts = [`${search.adults} adult${search.adults > 1 ? 's' : ''}`];
      if (search.children) parts.push(`${search.children} child${search.children > 1 ? 'ren' : ''}`);
      if (search.infants) parts.push(`${search.infants} infant${search.infants > 1 ? 's' : ''}`);
      parts.push(`${search.rooms} room${search.rooms > 1 ? 's' : ''}`);
      return parts.join(', ');
    };

    /** "2 adults · Nigeria passport" — the condensed summary-bar variant. */
    const travellerSummary = () =>
      `${search.adults} adult${search.adults > 1 ? 's' : ''} · ${search.nationality} passport`;

    /** Everyone who occupies a seat. Infants are priced separately in reality. */
    const payingTravellers = search.adults + search.children;

    return { search, setSearch, tier, setTier, travellerLabel, travellerSummary, payingTravellers };
  }, [search, tier]);

  return <TripContext.Provider value={value}>{children}</TripContext.Provider>;
}
